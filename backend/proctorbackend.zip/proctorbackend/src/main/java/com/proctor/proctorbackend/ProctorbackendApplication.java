package com.proctor.proctorbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProctorbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProctorbackendApplication.class, args);
	}

}
